# openWeathermapLaravel
1. openWeathermapLaravel is a Laravel 5.7 project that uses real-time weather detection.
2. It uses the Open Weather Map API.

Implementation
1. Git clone
cmd>git clone https://github.com/soundar8562/openWeathermapLaravel.git
2. Composer update
cmd> composer update
3. Migrate Tables
cmd> php artisan migrate

This cmd will create "city table" which is going to contain all city list

Note: You can import the all city list to your table by go thorugh this link - your_project_url/create

****************************************************************************************************
Make the issue section to for issues.
