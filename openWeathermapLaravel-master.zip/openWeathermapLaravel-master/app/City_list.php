<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City_list extends Model
{
     protected $fillable = ['name']; 
}
